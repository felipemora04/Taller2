package controlador;

import dao.ProductoDAO;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Scanner;
import modelo.Producto;

/**
 *
 * @author pmart
 */
public class ProductoController implements ActionListener {

    //Probando el metodo para ingresar
    public void Ingresar() {
        ProductoDAO vd = new ProductoDAO();
        Producto v = new Producto("PC","123123","5000","tecno");
        //Se crea un if para saber si el ingreso de datos fue exitoso o no
        if (vd.insertarDatos(v.getNombre(), v.getCodigo(), v.getPrecio(), v.getDescripcion())) {
            System.out.println("ingresado con exito");
        } else {
            System.out.println("UPS!");
        }
    }

    //Probando el metodo para obtener la informacion de la BD
    public void Ver() {
        ProductoDAO vd = new ProductoDAO();
        List productos = vd.listarDatos(); //A la lista le entrego los datos obtenidos desde el metodo del DAO
        for (int i = 0; i < productos.size(); i++) {
            System.out.println(productos.get(i).toString()); //Muestro info de productos
        }
    }

    //Probando el metodo para editar datos de la BD
    public void update() {
        ProductoDAO vd = new ProductoDAO();
        Scanner intro = new Scanner(System.in);
        //Usuario ingresa por consola los datos que quiere actualizar
        System.out.println("Ingrese Nombre a Buscar");
        String NombreActual = intro.next();
        System.out.println("Ingrese nuevo Nombre");
        String nuevoNombre = intro.next();
        System.out.println("Ingrese nuevo Codigo");
        String nuevoCodigo = intro.next();
        System.out.println("Ingrese nuevo Precio");
        String nuevoPrecio = intro.next();
        System.out.println("Ingrese nueva Descripcion");
        String nuevaDescripcion = intro.next();

        //Entrego un mensaje dependiendo del resultado de la transaccion
        if (vd.actualizarDatos(nuevoNombre, nuevoCodigo, nuevoPrecio, nuevaDescripcion, NombreActual)) {
            System.out.println("UPS!");
        } else {
            System.out.println("Actualizado!");
        }
    }

    //Probando metodo para eliminar
    public void eliminar() {
        ProductoDAO vd = new ProductoDAO();
        //Entrego un mensaje dependiendo del resultado de la transaccion
        if (vd.eliminarDatos("PC")) {
            System.out.println("Eliminado con exito");
        } else {
            System.out.println("UPS!");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();       
        if (comando == "ingresar") {
            Ingresar();
        } else if (comando == "ver") {
            Ver();
        } else if (comando == "update") {
            update();
        } else if (comando == "eliminar") {
            eliminar();
        }
    
        
        
    }

}
