package vista;

import controlador.ProductoController;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author pmart
 */
public class VistaProducto extends JFrame {
    
    private  JButton ingresar;
    private  JButton ver;
    private  JButton update;
    private  JButton eliminar;
    private  JPanel panel;

    public VistaProducto() {
        this.panel = new javax.swing.JPanel();
        this.ingresar = new javax.swing.JButton();
        this.ver = new javax.swing.JButton();
        this.update = new javax.swing.JButton();
        this.eliminar = new javax.swing.JButton();
        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        this.ingresar.setText("INGRESAR");
        this.ver.setText("VER");
        this.update.setText("UPDATE");
        this.eliminar.setText("ELIMINAR");
        this.setLocationRelativeTo(this);
        iniciarVista();
        
        ProductoController vc = new ProductoController();
        this.ingresar.addActionListener(vc);
        this.ingresar.setActionCommand("ingresar");
        this.ver.addActionListener(vc);
        this.ver.setActionCommand("ver");
        this.update.addActionListener(vc);
        this.update.setActionCommand("update");
        this.eliminar.addActionListener(vc);
        this.eliminar.setActionCommand("eliminar");
    }

    public void iniciarVista() {
        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(this.panel);
        this.panel.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(139, 139, 139)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(this.ingresar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(this.ver, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(this.update, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(this.eliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addContainerGap(168, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
                jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(this.ingresar)
                                .addGap(28, 28, 28)
                                .addComponent(this.ver)
                                .addGap(26, 26, 26)
                                .addComponent(this.update)
                                .addGap(31, 31, 31)
                                .addComponent(this.eliminar)
                                .addContainerGap(58, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(this.panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(this.panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }
    
}
