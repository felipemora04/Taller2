package vista;

import conexion.Conector;

/**
 *
 * @author pmart
 */
public class pruebaCon {
    public static void main(String[] args) {
            Conector con = new Conector();
            if (Conector.iniciarConexion()!= null) {
            System.out.println("CONECTADO");
        }else{
                System.out.println("ERROR");
            
            
            
            
                
            }
    }         
    
}
