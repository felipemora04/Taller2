package pruebaa;

import conexion.Conexion;
import java.sql.Connection;
import javax.swing.JOptionPane;

/**
 *
 * @author pmart
 */
public class Prueba {
    public static void main(String[] args) {
        Connection con;
        con = Conexion.iniciarConexion();
        if (con != null) {
            JOptionPane.showMessageDialog(null, "CONEXION EXITOSA");
        }else{
            JOptionPane.showMessageDialog(null, "ERROR EN LA CONEXION");
        }
        
    }
}
