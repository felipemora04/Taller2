package pruebaa;

import dao.trabajadorDAO;

/**
 *
 * @author pmart
 */
public class PruebaDAO {
    public static void main(String[] args) {
        trabajadorDAO user = new trabajadorDAO();
        if (user.insertar("admin", "admin")) {
            System.out.println("AGREGADO CON EXITO");
        }else{
            System.out.println("NO SE PUDO INGRESAR");
        }
    }
}
