package dao;

import conexion.Conector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import modelo.Producto;

/**
 *
 * @author pmart
 */
public class ProductoDAO {
    
    
    private static Connection con = null;
    private Statement statement = null;
    private ResultSet resultSet = null;
    
    //Constructor clase DAO
    public ProductoDAO() {
    }

    //Metodos del CRUD de la BD
    //Insertar - Ingresar
    //Los parametros que recibe son los datos que quiero agregar a la BD
    public boolean insertarDatos(String nombre, String codigo, String precio, String descripcion) {
        boolean resp = false; //Resultado de la transaccion
        try {
            con = Conector.iniciarConexion(); //inicio la conexion con la BD
            statement = con.createStatement(); //Abro la query
            String sql = "INSERT INTO  producto "
                    + " VALUES (null, '" + nombre + "', '" + codigo
                    + "', '" + precio + "', '" + descripcion + "')"; //Escribo la consulta en lenguaje SQL
            statement.executeUpdate(sql); //Ejecutando la query
            resp = true; //entrego el valor verdadero cuando se ejecuta correctamente
            statement.close(); //cierro la conexion
        } catch (SQLException e) {
            System.out.println("Error SQL"); //en caso de error de la query
        }
        return resp; //entrego true o false dependiendo del resultado
    }

    //Eliminar 
    //El parametro que recibe es el dato a bsucar para eliminar

    /**
     *
     * @param nombre
     * @return
     */
    public boolean eliminarDatos(String nombre) {
        boolean resp = false;
        try {
            con = Conector.iniciarConexion();
            statement = con.createStatement();
            String sql = "DELETE FROM producto WHERE nombre ='" + nombre + "'"; //Query para elminar
            statement.executeUpdate(sql);
            resp = true;
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error SQL");
        }
        return resp;
    }

    //Listar - Select (ver)
    //Entrega como resultado una Lista de datos extraidos de la base de datos
    public List listarDatos() {
        List productos = new ArrayList(); //Creo el arraylist que se va a llenar con los datos de la BD
        try {
            con = Conector.iniciarConexion();
            statement = con.createStatement();
            String sql = "SELECT * FROM producto"; //Query para obtener toda la informacion de la tabla
            resultSet = statement.executeQuery(sql); //Se obtienen los datos de la BD
            while (resultSet.next()) { //Recorriendo los datos obtenidos y almacenados en resultSet
                Producto v = new Producto(); //Creo el vehiculo del modelo
                v.setNombre(resultSet.getString("Nombre")); //asigno el nombre
                v.setCodigo(resultSet.getString("Codigo")); //asigno el codigo
                v.setPrecio(resultSet.getString("Precio")); //asigno el precio
                v.setDescripcion(resultSet.getString("Descripcion")); //asigno la Descripcion
                productos.add(v); //agrego el producto a la Lista
            }
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error SQL");
        }
        return productos; //Entrego una lista completa con la informacion de los productos
    }
    
    //Actualizar - Editar
    //Los parametros que recibe son los datos que se modificaran
    //Nombre actual sirve para encontrar el registro a modificar
    public boolean actualizarDatos(String nombre, String codigo, String precio, String descripcion, String nombreActual) {
        boolean resp = false;
        try {
            con = Conector.iniciarConexion();
            statement = con.createStatement();
            String sql = "UPDATE Producto "
                    + " SET nombre = '" + nombre + "', codigo = '" + codigo + "', precio ='" + precio + "' descripcion ='" + descripcion
                    + "' WHERE nombre='" + nombreActual + "'";
            statement.executeUpdate(sql);
            resp = true;
            statement.close();
        } catch (SQLException e) {
            System.out.println("Error SQL");
        }
        return resp;
    }

    public boolean insertarDatos(String usuario, String password) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
}
