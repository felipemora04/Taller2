package dao;

import conexion.Conexion;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pmart
 */
public class trabajadorDAO {
    static Connection con = null;
    private Statement statement = null;
    private final ResultSet resultSet = null;

    public trabajadorDAO() {
        if (con == null) {
            con = (Connection) Conexion.iniciarConexion();
        }
    }
    //Insertar datos en la tabla
    public boolean insertar(String usuario, String password){
        boolean respuesta = false;
        try{
            statement = con.createStatement();
            String sql = "INSERT INTO  user " + 
                                 " VALUES (null, '" + usuario + "', '" + password + "')";
            statement.executeUpdate(sql);
            respuesta = true;
        } catch (SQLException ex) {
            Logger.getLogger(trabajadorDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return respuesta;
    }

}
